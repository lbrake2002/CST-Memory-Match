package com.example.cstmemorymatch;

import android.content.Context;
import android.graphics.Color;
import android.media.Image;
import android.text.style.BackgroundColorSpan;
import android.widget.EditText;
import android.widget.ImageButton;

import java.io.Serializable;

public class Card
{
    ImageButton image;
    private int cardFace;
    final int cardBack = R.drawable.b;
    public boolean isFlipped = false;

    /**
     * Constructor for the card
     * Takes in a cardFace and a ImageButton
     * @param cardFace
     * @param button
     */
    public Card(int cardFace, ImageButton button) {
        this.cardFace = cardFace;
        image = button;
        image.setImageResource(cardBack);
    }

    /**
     * This method will flip the card to reveal its face side
     */
    public void flipCard()
    {
        image.setImageResource(cardFace);
        isFlipped = true;
    }

    /**
     * This method will flip the card back to its backside
     */
    public void flipToBack()
    {
        image.setImageResource(cardBack);
        isFlipped = false;
    }

    /**
     * This method will return the image of a card face
     * @return
     */
    public int getImg()
    {

        return this.cardFace;
    }


}
