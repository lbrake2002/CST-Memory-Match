package com.example.cstmemorymatch;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class FinishedActivity extends AppCompatActivity implements View.OnClickListener
{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finished);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        int guesses = bundle.getInt("guesses");

        TextView tvGuesses = findViewById(R.id.txtCongrats);
        tvGuesses.setText("You Won After " + guesses + " Guesses");
    }

    /**
     * This method will restart the game and go back to the MainActivity Page when the Play Again button
     * @param view
     */
    @Override
    public void onClick(View view)
    {
        Intent intent = new Intent(this, MainActivity.class);
        this.startActivity(intent);
    }
}
