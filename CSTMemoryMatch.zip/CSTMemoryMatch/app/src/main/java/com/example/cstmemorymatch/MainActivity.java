package com.example.cstmemorymatch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Card[][] cardArray = new Card[3][4];
    private boolean canCompare = false;
    private int masterRow,masterCol;
    private int totalGuesses = 0;
    private TextView txtGuesses;
    private int matches;
    private ImageButton btn00;
    private ImageButton btn01;
    private ImageButton btn02;
    private ImageButton btn03;
    private ImageButton btn10;
    private ImageButton btn11;
    private ImageButton btn12;
    private ImageButton btn13;
    private ImageButton btn20;
    private ImageButton btn21;
    private ImageButton btn22;
    private ImageButton btn23;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar gameToolbar = findViewById(R.id.gameMenu);
        gameToolbar.setTitle("CST Memory Match");
        setSupportActionBar(gameToolbar);

        txtGuesses = findViewById(R.id.txtGuess);

        btn00 = findViewById(R.id.btnCard00);
        btn01 = findViewById(R.id.btnCard01);
        btn02 = findViewById(R.id.btnCard02);
        btn03 = findViewById(R.id.btnCard03);
        btn10 = findViewById(R.id.btnCard10);
        btn11 = findViewById(R.id.btnCard11);
        btn12 = findViewById(R.id.btnCard12);
        btn13 = findViewById(R.id.btnCard13);
        btn20 = findViewById(R.id.btnCard20);
        btn21 = findViewById(R.id.btnCard21);
        btn22 = findViewById(R.id.btnCard22);
        btn23 = findViewById(R.id.btnCard23);

        genRandomArray(cardArray);
    }

    /**
     * This class will add the menu bar onto the top of the screen
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    /**
     * This method will allow the user to select the New Game menu item and restart the game
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.newGame:
                newGame();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * This click handler will execute cards flipping when a card is pressed
     * and will start a new game when the game game button is selected
     * @param view
     */
    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view)
    {
        switch (view.getId())
        {
            case R.id.btnCard00:
                isFlipped(0,0);
                break;
            case R.id.btnCard01:
                isFlipped(0,1);
                break;
            case R.id.btnCard02:
                isFlipped(0,2);
                break;
            case R.id.btnCard03:
                isFlipped(0,3);
                break;
                //
            case R.id.btnCard10:
                isFlipped(1,0);
                break;
            case R.id.btnCard11:
                isFlipped(1,1);
                break;
            case R.id.btnCard12:
                isFlipped(1,2);
                break;
            case R.id.btnCard13:
                isFlipped(1,3);
                break;
                //
            case R.id.btnCard20:
                isFlipped(2,0);
                break;
            case R.id.btnCard21:
                isFlipped(2,1);
                break;
            case R.id.btnCard22:
                isFlipped(2,2);
                break;
            case R.id.btnCard23:
                isFlipped(2,3);
                break;
            default:
                break;
        }
    }

    /**
     * This class will flip the card the is pressed
     * @param row
     * @param col
     */
    public void isFlipped(int row, int col)
    {
        if(!(cardArray[row][col].isFlipped))
        {
            flipCardSelected(row,col);
        }
    }

    public void updateGuesses()
    {
        txtGuesses.setText("You've made " + totalGuesses + " guesses");
    }


    /**
     * This method will start a new game by flipping all the cards onto their backs
     * and randomly place them within the grid.
     */
    public void newGame()
    {
        for(int i = 0; i < cardArray.length; i++)
        {
            for(int j = 0; j < cardArray[i].length; j++)
            {
                cardArray[i][j].flipToBack();
            }
        }
        genRandomArray(cardArray);
        totalGuesses = 0;
        updateGuesses();
        matches = 0;
    }

    /**
     * This method will flip a card, and check to see if their the same
     * If not it will flip back to face down
     */
    public void flipCardSelected(int row, int col)
    {
        cardArray[row][col].flipCard();
        if(canCompare)
        {
            if(cardArray[masterRow][masterCol].getImg() != cardArray[row][col].getImg())
            {
                new Thread(() -> {

                    try
                    {
                        Thread.sleep(500);
                        cardArray[masterRow][masterCol].flipToBack();
                        cardArray[row][col].flipToBack();
                    }
                    catch (InterruptedException e)
                    {
                        e.printStackTrace();
                    }
                }).start();
                totalGuesses++;

            }
            else
            {
                totalGuesses++;
                matches++;
                if(matches == 6)
                {
                    goToFinished();
                }

            }
            canCompare = false;
            updateGuesses();
        }
        else
        {
            canCompare = true;
            masterRow = row;
            masterCol = col;
        }
    }

    /**
     * This method will go to the finished page once the user has correctly guessed all the matches
     */
    public void goToFinished()
    {
        Intent intent = new Intent(this, FinishedActivity.class);
        intent.putExtra("guesses", totalGuesses);
        this.startActivity(intent);
    }


    /**
     * This method will generate two of each cards and place them randomly into the array cardsArray
     * @param cards
     */
    public void genRandomArray(Card[][] cards)
    {
        int[] numCounter = new int[6];
        int rand;
        for(int i = 0; i < cards.length; i++)
        {
            for(int j = 0; j < cards[i].length;j++)
            {
                rand = (int) Math.floor(Math.random() *6);
                while(numCounter[rand] >= 2)
                {
                    rand = (int) Math.floor(Math.random() *6);
                }
                numCounter[rand]++;
                callCard(rand, i, j);

            }
        }
    }

    /**
     * This method will get the cards and their faces
     * @param nVal
     * @param row
     * @param col
     * @param ref
     */
    public void getCard(int nVal, int row, int col, ImageButton ref)
    {
        switch (nVal)
        {
            case 0:
                cardArray[row][col] = new Card(R.drawable.ca, ref);
                break;
            case 1:
                cardArray[row][col] = new Card(R.drawable.ck, ref);
                break;
            case 2:
                cardArray[row][col] = new Card(R.drawable.cq, ref);
                break;
            case 3:
                cardArray[row][col] = new Card(R.drawable.da, ref);
                break;
            case 4:
                cardArray[row][col] = new Card(R.drawable.dk, ref);
                break;
            case 5:
                cardArray[row][col] = new Card(R.drawable.dq, ref);
                break;
            default:
                break;
        }
    }

    /**
     * This method will call the card
     * @param nVal
     * @param row
     * @param col
     */
    public void callCard(int nVal, int row, int col)
    {
        switch(row)
        {
            case 0:
                switch (col)
                {
                    case 0:
                        getCard(nVal, row, col, btn00);
                        break;
                    case 1:
                        getCard(nVal, row, col, btn01);
                        break;
                    case 2:
                        getCard(nVal, row, col, btn02);
                        break;
                    case 3:
                        getCard(nVal, row, col, btn03);
                        break;
                    default:
                        break;
                }
                break;
            case 1:
                switch (col)
                {
                    case 0:
                        getCard(nVal, row, col, btn10);
                        break;
                    case 1:
                        getCard(nVal, row, col, btn11);
                        break;
                    case 2:
                        getCard(nVal, row, col, btn12);
                        break;
                    case 3:
                        getCard(nVal, row, col, btn13);
                        break;
                    default:
                        break;
                }
                break;
            case 2:
                switch (col)
                {
                    case 0:
                        getCard(nVal, row, col, btn20);
                        break;
                    case 1:
                        getCard(nVal, row, col, btn21);
                        break;
                    case 2:
                        getCard(nVal, row, col, btn22);
                        break;
                    case 3:
                        getCard(nVal, row, col, btn23);
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }
}